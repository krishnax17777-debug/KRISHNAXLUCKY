// List of ad server addresses (short list – you can add more)
const adServers = [
  "doubleclick.net",
  "googlesyndication.com",
  "googleadservices.com",
  "adsafeprotected.com",
  "adservice.google.com"
];

// When a request is about to happen, check the address
chrome.webRequest.onBeforeRequest.addListener(
  function(details) {
    for (let ad of adServers) {
      if (details.url.includes(ad)) {
        // If it's an ad, cancel it!
        return { cancel: true };
      }
    }
    return { cancel: false }; // otherwise let it through
  },
  { urls: ["<all_urls>"] },
  ["blocking"]
);